import java.util.Arrays;

// Press Shift twice to open the Search Everywhere dialog and type `show whitespaces`,
// then press Enter. You can now see whitespace characters in your code.
public class Main {
    public static void main(String[] args) {
        int[] arrayA = {1,4,3,6,9,2,6};

        System.out.println(Arrays.toString(trovaDivisibili(arrayA,3)));
        System.out.println(Arrays.toString(trovaDivisibili(arrayA,2)));
        System.out.println(Arrays.toString(trovaDivisibili(arrayA,1)));
        System.out.println(Arrays.toString(trovaDivisibili(arrayA,5)));
    }
    public static int[] trovaDivisibili(int[] arrayA, int k){
        int nTrovati = 0;
        for (int i=0; i<arrayA.length; i++){
            if (arrayA[i]%k==0){
                nTrovati+=1;
            }
        }
        int[] arrayB = new int[nTrovati];
        nTrovati=0;
        for (int i=0; i<arrayA.length; i++){
            if (arrayA[i]%k==0){
                arrayB[nTrovati] = arrayA[i];
                nTrovati+=1;
            }
        }
        return arrayB;
    }
}